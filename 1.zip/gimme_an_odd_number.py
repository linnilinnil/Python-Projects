input_list = []
while True:
    in_val = input("Please enter an integer.")
    input_list.append(int(in_val))
    if int(in_val) %2 != 0:
        break;     
print(input_list) 