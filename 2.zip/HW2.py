# HW2
# Name:
# Collaborators:
# Date:

import random

def count_characters(s):
    """Count the number of occurrences of each character in a string. 
    Args:
        s: str, the string in which to count. 
    Returns:
        a dict keyed by characters whose values are the number of occurrences in s
    """
    return {key:s.count(key) for key in s}


def count_ngrams(s, n):
    """Count the number of occurrences of n-grams in a string. 
    Args:
        s: str.
        n: positive int. should have default value 1.
    Returns:
        a dict keyed by n-grams whose values are the number of occurrences in s
    """
    d = {}
   # wlist = re.split(r'/W+', s) but then we are treating emma as a whole string
   # for word in wlist:
    for i in range(len(s)-n+1):
        key = s[i:i+n]
        if key in d:
                d.update({key:d[key]+1})
        else:
            d.update({key:1})
    return d

def markov_text(s, n, length, seed = "Emma Woodhouse"):
    """Generate fake text according to an n-th order Markov model, with data from a user-supplied corpus. 
    Args:
        s: str. the text from which to learn grams.
        n: positive int. the order of the Markov model. 
        length: positive int. the number of synthetic characters to generate. should have a default value. 
        seed: str. should have a default value.
    Returns:
        The output string fake_text. fake_text starts with the seed. 
        length of fake_text = length of seed + argument 'length'
    """
    #check validity of seed
    if (len(seed) < n):
        seed = s[0:n]
    #initialize fake_text
    fake_text = seed
    #calculate n+1 gram dictionary
    gram_dict = count_ngrams(s,n+1)
    while len(fake_text) < length + len(seed) :
        match = {key:val for key,val in gram_dict.items() if key[0:n] == fake_text[-n:]}
        selected = random.choices(list(match.keys()),list(match.values()))[0]
        fake_text += selected[-1]
    return fake_text